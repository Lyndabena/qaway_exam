package datastructure.collections;

import java.util.LinkedList;
import java.util.List;

public class UseLinkedList {

    /*
     *
     * demonstrate how to use LinkedList that includes add,remove elements
     * use (1) for each loop, for loop (2) and (3) while loop with Iterator to retrieve and print out data
     *
     */

    public static void main(String[] args) {

        List<Integer> list = new LinkedList<>();


    }
}
