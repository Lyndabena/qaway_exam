package shufflegame;

public class RunGame {

    public static void main(String[] args) {

        //run this main method to play

        ShuffleGame shuffleGame = new ShuffleGame();

        shuffleGame.play();

    }
}
