-----------------------------------------------------------------
Java Coding Project
-----------------------------------------------------------------

**important:** please read this guidance

clone the project.

work on the different topics.

you can check-in your work in multiple pushes.

follow the below steps bellow:

**required:**

_set git on your local machine_

_create github token and set it up locally_

_create your own new repo on your github_

_then you can follow the git commands_

-----------------------------------------------------------------

**to clone the project:**

git clone _https://github.com/nacerhadjsaid/java-coding-exam.git_

-----------------------------------------------------------------

**to push for the first time:**

git remote rm origin

git remote add origin <_your github url_>

git init

git add .

git commit -m "name of the topic you are pushing"

git push -u origin master

-----------------------------------------------------------------

**to keep pushing:**

git add .

git commit -m "name of the topic you are pushing"

git push

-----------------------------------------------------------------

**submit your work:**

go to classroom, classwork, on the midterm assignment, add your github link